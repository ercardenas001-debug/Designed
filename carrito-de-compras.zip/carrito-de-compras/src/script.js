const listaCarrito = document.getElementById('lista-carrito');

function agregarProducto(nombreProducto) {
  // Elimina el mensaje de "No hay productos" si existe
  const noProductos = listaCarrito.querySelector('.text-muted');
  if (noProductos) {
    noProductos.remove();
  }

  const li = document.createElement('li');
  li.className = 'list-group-item agregado bg-black text-white border-bottom border-light';
  li.textContent = nombreProducto;
  listaCarrito.appendChild(li);

  // Quitar la clase 'agregado' después de 1 segundo
  setTimeout(() => {
    li.classList.remove('agregado');
  }, 1000);
}

function eliminarProducto() {
  const items = listaCarrito.getElementsByTagName('li');
  if (items.length > 0) {
    const ultimo = items[items.length - 1];
    ultimo.classList.add('eliminado');
    setTimeout(() => {
      ultimo.remove();
      if (listaCarrito.children.length === 0) {
        const liVacio = document.createElement('li');
        liVacio.className = 'list-group-item text-muted text-center bg-black';
        liVacio.textContent = 'No hay productos';
        listaCarrito.appendChild(liVacio);
      }
    }, 500);
  }
}